export type UserRole = 
  | 'admin'         // مالك / مسؤول عام
  | 'manager'       // مدير
  | 'accountant'    // محاسب
  | 'sales'         // موظف مبيعات
  | 'warehouse'     // أمين مستودع
  | 'representative';// مندوب مبيعات

export interface UserPermissions {
  canView: boolean;
  canAdd: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canPrint: boolean;
  canExport: boolean;
  canViewReports: boolean;
  canManageSales: boolean;
  canManagePurchases: boolean;
  canManageInventory: boolean;
  canManageWarehouses: boolean;
  canManageCashboxes: boolean;
  canManageAccounts: boolean;
  canManageReps: boolean;
  canManageTransfers: boolean;
  canManageEmployees: boolean;
  canManageSalaries: boolean;
  canManageUsers: boolean;
  canManageSettings: boolean;
  canAllowNegativeInventory: boolean;
}

export interface User {
  id: string;
  fullName: string;
  username: string;
  passwordHash: string;
  phone: string;
  role: UserRole;
  jobTitle: string;
  department: string;
  address?: string;
  notes?: string;
  isActive: boolean;
  mustChangePassword?: boolean;
  lastLogin?: string;
  permissions: UserPermissions;
  createdAt: string;
}

export interface ProductUnit {
  id: string;
  name: string;        // مثلا: كرتونة، باكت، قطعة، كيلو
  conversionFactor: number; // كم تحتوي من الوحدة الصغرى الأساسية
  sellingPrice: number;
  purchasePrice: number;
  barcode?: string;
}

export interface Product {
  id: string;
  code: string;
  barcode: string;
  name: string;
  category: string;
  baseUnit: string;     // الوحدة الصغرى الأساسية: قطعة، كيس، كيلو
  units: ProductUnit[]; // وحدات القياس الإضافية
  purchasePrice: number;
  sellingPrice: number;
  minStockLevel: number;
  stockPerWarehouse: Record<string, number>; // warehouseId -> quantity in base unit
  image?: string;
  status: 'active' | 'archived';
  notes?: string;
  createdAt: string;
}

export interface Warehouse {
  id: string;
  name: string;
  code: string;
  location: string;
  managerName?: string;
  phone?: string;
  isDefault: boolean;
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  phone: string;
  address: string;
  photo?: string;
  notes?: string;
  openingBalance: number; // موجب = عليه دين للشركة، سالب = له رصيد دائن
  currentBalance: number;
  status: 'active' | 'blocked';
  // التاريخ الفعلي لأسعار الشراء السابقة لكل منتج: productId -> prices array [oldest to newest]
  priceHistory: Record<string, number[]>;
  createdAt: string;
}

export interface Supplier {
  id: string;
  code: string;
  name: string;
  phone: string;
  address: string;
  notes?: string;
  openingBalance: number; // موجب = له مستحقات علينا، سالب = دفع زيادة
  currentBalance: number;
  createdAt: string;
}

export interface InvoiceItem {
  productId: string;
  productName: string;
  barcode: string;
  unit: string;
  unitFactor: number;
  quantity: number;
  unitPrice: number;
  purchasePriceAtTime: number;
  discount: number; // خصم بالجنيه لكل بند
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  type: 'sales' | 'purchase';
  date: string;
  customerId?: string;
  customerName?: string;
  supplierId?: string;
  supplierName?: string;
  representativeId?: string;
  representativeName?: string;
  warehouseId: string;
  warehouseName: string;
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paidAmount: number;
  remainingAmount: number;
  paymentType: 'cash' | 'credit' | 'partial';
  paymentMethod: 'cash' | 'bank' | 'cheque';
  cashboxId: string;
  status: 'draft' | 'confirmed' | 'cancelled';
  notes?: string;
  createdBy: string;
  createdAt: string;
  returnedQuantityByItem?: Record<string, number>;
}

export interface InvoiceReturnItem {
  productId: string;
  productName: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface InvoiceReturn {
  id: string;
  returnNumber: string;
  type: 'sales_return' | 'purchase_return';
  originalInvoiceId: string;
  originalInvoiceNumber: string;
  date: string;
  partyId: string; // customerId or supplierId
  partyName: string;
  warehouseId: string;
  warehouseName: string;
  items: InvoiceReturnItem[];
  grandTotal: number;
  refundType: 'cash' | 'balance';
  cashboxId?: string;
  reason: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
}

export interface Cashbox {
  id: string;
  name: string;
  type: 'cashbox' | 'bank';
  accountNumber?: string;
  openingBalance: number;
  currentBalance: number;
  isDefault: boolean;
}

export type FinancialTransactionType =
  | 'income'             // إيراد / سند قبض
  | 'expense'            // مصروف / سند صرف
  | 'deposit'            // إيداع بنكي
  | 'withdrawal'         // سحب
  | 'transfer'           // تحويل بين الخزائن
  | 'customer_payment'   // تحصيل من عميل
  | 'supplier_payment'   // سداد لمورد
  | 'salary_payout'      // صرف راتب
  | 'rep_transfer';      // تحويل مندوب معتمد

export interface FinancialTransaction {
  id: string;
  transactionNumber: string;
  date: string;
  type: FinancialTransactionType;
  cashboxId: string;
  cashboxName: string;
  targetCashboxId?: string;
  targetCashboxName?: string;
  amount: number;
  category: string;
  relatedDocType?: 'sales' | 'purchase' | 'sales_return' | 'purchase_return' | 'rep_transfer' | 'salary' | 'manual';
  relatedDocId?: string;
  relatedDocNumber?: string;
  partyId?: string;
  partyName?: string;
  description: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
}

export type ChequeStatus = 'new' | 'pending' | 'collected' | 'rejected' | 'returned';

export interface Cheque {
  id: string;
  chequeNumber: string;
  type: 'incoming' | 'outgoing';
  bankName: string;
  amount: number;
  issueDate: string;
  dueDate: string;
  partyId?: string;
  partyName: string;
  relatedDocNumber?: string;
  status: ChequeStatus;
  cashboxId?: string;
  notes?: string;
  collectedDate?: string;
  createdAt: string;
}

export interface InstallmentItem {
  id: string;
  installmentNumber: number;
  dueDate: string;
  amount: number;
  paidAmount: number;
  status: 'pending' | 'paid' | 'overdue';
  paidDate?: string;
  notes?: string;
}

export interface InstallmentSchedule {
  id: string;
  scheduleNumber: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  invoiceNumber?: string;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  items: InstallmentItem[];
  notes?: string;
  createdAt: string;
}

export interface Representative {
  id: string;
  name: string;
  phone: string;
  vehicleNumber?: string;
  userId?: string; // حساب الدخول المرتبط
  openingBalance: number;
  currentBalance: number;
  commissionRate?: number;
  notes?: string;
  status: 'active' | 'inactive';
}

export type RepTransferStatus = 
  | 'new'               // جديد
  | 'awaiting_receipt'  // قيد الاستلام
  | 'received'          // تم الاستلام
  | 'rejected'          // مرفوض
  | 'cancelled';        // ملغى

export interface RepTransfer {
  id: string;
  transferNumber: string; // ترقيم تسلسلي فريد
  date: string;
  timestamp: string;
  direction: 'owner_to_rep' | 'rep_to_owner'; // اتجاه التحويل
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  amount: number;
  cashboxId: string; // الخزينة المتأثرة للفرع
  cashboxName: string;
  notes?: string;
  status: RepTransferStatus;
  sentAt: string;
  confirmedAt?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  confirmedBy?: string;
  auditTrail: Array<{
    timestamp: string;
    action: string;
    user: string;
    note?: string;
  }>;
}

export interface Employee {
  id: string;
  code: string;
  name: string;
  phone: string;
  jobTitle: string;
  department: string;
  nationalId?: string;
  basicSalary: number;
  hireDate: string;
  status: 'active' | 'suspended';
  notes?: string;
}

export interface EmployeeAdvanceDeduction {
  id: string;
  employeeId: string;
  employeeName: string;
  type: 'advance' | 'deduction' | 'bonus'; // سلفة | خصم | مكافأة
  amount: number;
  date: string;
  reason: string;
  cashboxId?: string;
  isSettled: boolean;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  status: 'present' | 'absent' | 'leave' | 'late';
  checkIn?: string;
  checkOut?: string;
  notes?: string;
}

export interface SalaryPayroll {
  id: string;
  payrollNumber: string;
  month: number;
  year: number;
  employeeId: string;
  employeeName: string;
  basicSalary: number;
  advancesTotal: number;
  deductionsTotal: number;
  bonusesTotal: number;
  netSalary: number;
  status: 'draft' | 'paid';
  paidDate?: string;
  cashboxId?: string;
  notes?: string;
}

export interface ExpenseIncomeRecord {
  id: string;
  recordNumber: string;
  type: 'expense' | 'income';
  category: string;
  amount: number;
  date: string;
  cashboxId: string;
  cashboxName: string;
  paymentMethod: string;
  recipientOrPayer: string;
  notes?: string;
  attachmentName?: string;
  createdBy: string;
  createdAt: string;
}

export interface StockMovement {
  id: string;
  date: string;
  type: 'opening' | 'purchase' | 'sale' | 'sale_return' | 'purchase_return' | 'transfer_in' | 'transfer_out' | 'adjustment' | 'damaged';
  productId: string;
  productName: string;
  warehouseId: string;
  warehouseName: string;
  targetWarehouseId?: string;
  targetWarehouseName?: string;
  quantity: number; // in base unit
  unitCost: number;
  referenceId?: string;
  referenceNumber?: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  recordId?: string;
  details: string;
}

export type NetworkSyncStatus = 'connected' | 'disconnected' | 'synchronizing' | 'pending' | 'error';

export interface SystemSettings {
  companyName: string;
  companySubtitle: string;
  phone1: string;
  phone2: string;
  address: string;
  commercialRegistration: string;
  taxNumber: string;
  currency: string;
  defaultPrintMode: 'a4' | 'thermal80' | 'thermal58';
  invoiceNotes: string;
  allowNegativeStock: boolean;
}
