import React, { useState, useMemo } from 'react';
import { 
  Plus, Search, Filter, Printer, Download, Eye, XCircle, 
  CheckCircle, FileText, Calendar, ArrowLeftRight 
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import { useAuth } from '../../../context/AuthContext';
import { Invoice } from '../../../types';
import { NewSaleInvoiceModal } from './NewSaleInvoiceModal';
import { PrintDocumentModal, PrintData } from '../../common/PrintDocument';
import { exportToExcel } from '../../common/ExcelExporter';

export const SalesInvoicesView: React.FC = () => {
  const { invoices, customers, settings, cancelInvoice } = useData();
  const { hasPermission } = useAuth();

  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomerFilter, setSelectedCustomerFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  // Print modal state
  const [printData, setPrintData] = useState<PrintData | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Detail View modal state
  const [activeInvoice, setActiveInvoice] = useState<Invoice | null>(null);

  // Filter only sales invoices
  const salesInvoices = useMemo(() => {
    return invoices.filter(i => i.type === 'sales');
  }, [invoices]);

  const filteredInvoices = useMemo(() => {
    return salesInvoices.filter(inv => {
      const matchSearch = 
        inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (inv.customerName && inv.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (inv.representativeName && inv.representativeName.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchCustomer = selectedCustomerFilter ? inv.customerId === selectedCustomerFilter : true;
      const matchDateFrom = dateFrom ? inv.date >= dateFrom : true;
      const matchDateTo = dateTo ? inv.date <= dateTo : true;

      return matchSearch && matchCustomer && matchDateFrom && matchDateTo;
    });
  }, [salesInvoices, searchTerm, selectedCustomerFilter, dateFrom, dateTo]);

  // Open print preview
  const handlePrint = (inv: Invoice) => {
    setPrintData({
      title: 'فاتورة مبيعات أولاد سليم',
      docNumber: inv.invoiceNumber,
      docType: 'فاتورة مبيعات',
      date: inv.date,
      partyName: inv.customerName,
      warehouseName: inv.warehouseName,
      representativeName: inv.representativeName,
      paymentType: inv.paymentType === 'cash' ? 'نقدي' : inv.paymentType === 'credit' ? 'آجل' : 'جزئي',
      items: inv.items.map(it => ({
        name: it.productName,
        unit: it.unit,
        quantity: it.quantity,
        price: it.unitPrice,
        discount: it.discount,
        total: it.total,
      })),
      subtotal: inv.subtotal,
      discountTotal: inv.discountTotal,
      grandTotal: inv.grandTotal,
      paidAmount: inv.paidAmount,
      remainingAmount: inv.remainingAmount,
      notes: inv.notes,
    });
    setIsPrintModalOpen(true);
  };

  // Export to Excel
  const handleExportExcel = () => {
    const headers = [
      'رقم الفاتورة',
      'التاريخ',
      'العميل',
      'المندوب',
      'المستودع',
      'الإجمالي',
      'المدفوع',
      'المتبقي',
      'نوع السداد',
      'الحالة',
      'الملاحظات'
    ];

    const rows = filteredInvoices.map(inv => [
      inv.invoiceNumber,
      inv.date,
      inv.customerName || 'نقدي',
      inv.representativeName || '-',
      inv.warehouseName,
      inv.grandTotal,
      inv.paidAmount,
      inv.remainingAmount,
      inv.paymentType,
      inv.status,
      inv.notes || ''
    ]);

    exportToExcel(`فواتير_مبيعات_أولاد_سليم_${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  const handleCancelInvoice = async (inv: Invoice) => {
    const reason = prompt('يرجى كتابة سبب إلغاء الفاتورة:');
    if (!reason) return;
    await cancelInvoice(inv.id, reason);
  };

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">إدارة فواتير المبيعات</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            عرض وتوليد وطباعة فواتير مبيعات المواد الغذائية ومتابعة التحصيلات والديون
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>تصدير Excel</span>
          </button>

          <button
            onClick={() => setIsNewModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-900 hover:bg-blue-950 text-white text-xs font-black shadow-md shadow-blue-900/20 transition-all active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>فاتورة بيع جديدة</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        {/* Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="بحث برقم الفاتورة أو العميل أو المندوب..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2 pr-9 pl-3 text-xs focus:bg-white focus:border-blue-600 outline-hidden"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
        </div>

        {/* Customer Filter */}
        <div>
          <select
            value={selectedCustomerFilter}
            onChange={(e) => setSelectedCustomerFilter(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:bg-white focus:border-blue-600 outline-hidden"
          >
            <option value="">-- جميع العملاء --</option>
            {customers.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        {/* Date From */}
        <div>
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-semibold focus:bg-white focus:border-blue-600 outline-hidden"
            placeholder="من تاريخ"
          />
        </div>

        {/* Date To */}
        <div>
          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-semibold focus:bg-white focus:border-blue-600 outline-hidden"
            placeholder="إلى تاريخ"
          />
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3.5">رقم الفاتورة</th>
                <th className="p-3.5">التاريخ</th>
                <th className="p-3.5">العميل</th>
                <th className="p-3.5">المندوب</th>
                <th className="p-3.5">المستودع</th>
                <th className="p-3.5">الإجمالي</th>
                <th className="p-3.5">المدفوع</th>
                <th className="p-3.5">المتبقي</th>
                <th className="p-3.5">نوع الدفع</th>
                <th className="p-3.5">الحالة</th>
                <th className="p-3.5 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={11} className="p-8 text-center text-slate-400">
                    لا توجد فواتير مبيعات مطابقة لمعايير البحث الحالية
                  </td>
                </tr>
              ) : (
                filteredInvoices.map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-bold font-mono text-blue-900">{inv.invoiceNumber}</td>
                    <td className="p-3.5 font-mono text-slate-600">{inv.date}</td>
                    <td className="p-3.5 font-bold text-slate-800">{inv.customerName || 'نقدي عام'}</td>
                    <td className="p-3.5 text-slate-600">{inv.representativeName || '-'}</td>
                    <td className="p-3.5 text-slate-600">{inv.warehouseName}</td>
                    <td className="p-3.5 font-black text-slate-900">{inv.grandTotal.toLocaleString()} {settings.currency}</td>
                    <td className="p-3.5 font-bold text-emerald-700">{inv.paidAmount.toLocaleString()}</td>
                    <td className="p-3.5 font-bold text-red-600">{inv.remainingAmount.toLocaleString()}</td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        inv.paymentType === 'cash' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                        inv.paymentType === 'credit' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                        'bg-blue-50 text-blue-800 border border-blue-200'
                      }`}>
                        {inv.paymentType === 'cash' ? 'نقدي' : inv.paymentType === 'credit' ? 'آجل' : 'جزئي'}
                      </span>
                    </td>
                    <td className="p-3.5">
                      {inv.status === 'confirmed' ? (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                          مؤكدة
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 text-[10px] font-bold">
                          ملغاة
                        </span>
                      )}
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handlePrint(inv)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-blue-900 hover:bg-blue-50 transition-colors"
                          title="طباعة (A4 / حراري 80mm / 58mm)"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setActiveInvoice(inv)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-blue-900 hover:bg-blue-50 transition-colors"
                          title="عرض تفاصيل الفاتورة"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {inv.status === 'confirmed' && (
                          <button
                            onClick={() => handleCancelInvoice(inv)}
                            className="p-1.5 rounded-lg text-red-400 hover:text-red-700 hover:bg-red-50 transition-colors"
                            title="إلغاء الفاتورة وعكس المخزون"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Invoice Modal */}
      <NewSaleInvoiceModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        onInvoiceCreated={(newInv) => {
          handlePrint(newInv);
        }}
      />

      {/* Print Document Modal */}
      <PrintDocumentModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        data={printData}
      />

      {/* View Detail Modal */}
      {activeInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 text-right max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-3 mb-4">
              <h3 className="text-base font-black text-slate-900">
                تفاصيل الفاتورة: {activeInvoice.invoiceNumber}
              </h3>
              <button
                onClick={() => setActiveInvoice(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                إغلاق ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs mb-4 p-3 bg-slate-50 rounded-xl">
              <div>
                <p className="text-slate-500">العميل: <strong className="text-slate-800">{activeInvoice.customerName}</strong></p>
                <p className="text-slate-500">المستودع: <strong className="text-slate-800">{activeInvoice.warehouseName}</strong></p>
              </div>
              <div>
                <p className="text-slate-500">التاريخ: <strong className="font-mono text-slate-800">{activeInvoice.date}</strong></p>
                <p className="text-slate-500">المندوب: <strong className="text-slate-800">{activeInvoice.representativeName || '-'}</strong></p>
              </div>
            </div>

            <table className="w-full text-right text-xs mb-4">
              <thead>
                <tr className="bg-slate-100 font-bold border-b">
                  <th className="p-2">الصنف</th>
                  <th className="p-2 text-center">الوحدة</th>
                  <th className="p-2 text-center">الكمية</th>
                  <th className="p-2 text-center">السعر</th>
                  <th className="p-2 text-center">الإجمالي</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {activeInvoice.items.map((it, i) => (
                  <tr key={i}>
                    <td className="p-2 font-semibold">{it.productName}</td>
                    <td className="p-2 text-center">{it.unit}</td>
                    <td className="p-2 text-center font-bold">{it.quantity}</td>
                    <td className="p-2 text-center">{it.unitPrice}</td>
                    <td className="p-2 text-center font-bold text-blue-900">{it.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="flex justify-between items-center pt-3 border-t text-xs">
              <div className="text-slate-600">
                صافي الفاتورة: <strong className="text-sm font-black text-blue-950">{activeInvoice.grandTotal} {settings.currency}</strong>
              </div>
              <button
                onClick={() => {
                  const inv = activeInvoice;
                  setActiveInvoice(null);
                  handlePrint(inv);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-blue-900 text-white rounded-xl font-bold"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة هذه الفاتورة</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
