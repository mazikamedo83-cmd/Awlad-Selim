@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo يجب تثبيت Node.js LTS قبل التشغيل.
  pause
  exit /b 1
)
if not exist node_modules (
  echo جاري تثبيت مكتبات المشروع - يلزم اتصال إنترنت في أول مرة...
  call npm install
  if errorlevel 1 (
    echo فشل تثبيت الحزم. راجع رسالة npm ثم أعد المحاولة.
    pause
    exit /b 1
  )
)
start "AWLAD SELIM LAN SERVER" cmd /k "npm run server"
start "AWLAD SELIM WEB APP" cmd /k "npm run dev"
echo.
echo السيرفر: http://localhost:3000/api/health
echo البرنامج: http://localhost:5173
echo لتوصيل أجهزة الشبكة، اضبط IP جهاز السيرفر من الإعدادات داخل البرنامج.
pause
