import React, { useState } from 'react';
import { 
  Settings, Save, Download, Upload, Database, RefreshCw, 
  Printer, Building2, ShieldCheck, Check, AlertCircle, Trash2, RotateCcw 
} from 'lucide-react';
import { useData } from '../../../context/DataContext';

export const SettingsView: React.FC = () => {
  const { settings, updateSettings, exportBackup, importBackup, resetSystemToFresh } = useData();

  const [formData, setFormData] = useState({ ...settings });
  const [isSaved, setIsSaved] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  const handleResetSystem = async () => {
    const confirmed = window.confirm(
      'تحذير هام: هل أنت متأكد تماماً من تصفير كافة بيانات البرنامج وحذف كافة الأصناف والعملاء والموردين والفواتير والموظفين والمناديب نهائياً والبدء كمنظومة جديدة فارغة؟'
    );
    if (!confirmed) return;

    setIsResetting(true);
    await resetSystemToFresh();
    setIsResetting(false);
    alert('تم تصفير المنظومة بالكامل بنجاح وبدء قاعدة بيانات جديدة وفارغة.');
    window.location.reload();
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      const res = await importBackup(content);
      if (res.success) {
        alert('تمت استعادة قاعدة البيانات بنجاح! سيتم تحديث الصفحة الآن.');
        window.location.reload();
      } else {
        setImportError(res.error || 'فشلت استعادة النسخة الاحتياطية');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">إعدادات النظام والنسخ الاحتياطي</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            تخصيص بيانات المنشأة، هوية الفواتير، ونظام الحفظ والنسخ الاحتياطي الشامل
          </p>
        </div>
        <img
          src="/assets/aistudio/file_0000000046a0820a8345a04b7c1f090a_737bd9c1.png"
          alt="أولاد سليم"
          className="h-10 w-auto object-contain"
        />
      </div>

      {isSaved && (
        <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>تم حفظ الإعدادات بنجاح</span>
        </div>
      )}

      {importError && (
        <div className="p-3 bg-red-50 text-red-800 border border-red-200 rounded-xl text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          <span>{importError}</span>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSave} className="space-y-6 text-xs">
        {/* Company Info */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-black text-slate-900 border-b pb-2 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-900" />
            <span>بيانات منشأة أولاد سليم ورأس الفواتير</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">اسم المنشأة التجاري:</label>
              <input
                type="text"
                required
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="w-full border rounded-xl p-2.5 font-bold"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">الوصف الفرعي بالترويسة:</label>
              <input
                type="text"
                value={formData.companySubtitle}
                onChange={(e) => setFormData({ ...formData, companySubtitle: e.target.value })}
                className="w-full border rounded-xl p-2.5"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold mb-1">رقم الهاتف 1:</label>
              <input
                type="text"
                value={formData.phone1}
                onChange={(e) => setFormData({ ...formData, phone1: e.target.value })}
                className="w-full border rounded-xl p-2.5 font-mono"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">رقم الهاتف 2:</label>
              <input
                type="text"
                value={formData.phone2}
                onChange={(e) => setFormData({ ...formData, phone2: e.target.value })}
                className="w-full border rounded-xl p-2.5 font-mono"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">العملة الافتراضية:</label>
              <input
                type="text"
                value={formData.currency}
                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                className="w-full border rounded-xl p-2.5 font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold mb-1">العنوان والمقر الرئيسي والمستودعات:</label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full border rounded-xl p-2.5"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">رقم السجل التجاري:</label>
              <input
                type="text"
                value={formData.commercialRegistration}
                onChange={(e) => setFormData({ ...formData, commercialRegistration: e.target.value })}
                className="w-full border rounded-xl p-2.5 font-mono"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">رقم البطاقة الضريبية:</label>
              <input
                type="text"
                value={formData.taxNumber}
                onChange={(e) => setFormData({ ...formData, taxNumber: e.target.value })}
                className="w-full border rounded-xl p-2.5 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Print & Inventory Settings */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-black text-slate-900 border-b pb-2 flex items-center gap-2">
            <Printer className="w-4 h-4 text-blue-900" />
            <span>إعدادات الطباعة وشروط الفواتير والمخزون</span>
          </h3>

          <div>
            <label className="block font-bold mb-1">نوع الطباعة الافتراضي عند فتح الفواتير:</label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, defaultPrintMode: 'a4' })}
                className={`p-3 border rounded-xl font-bold transition-all ${
                  formData.defaultPrintMode === 'a4' ? 'bg-blue-900 text-white' : 'bg-slate-50'
                }`}
              >
                ورق قياسي A4
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, defaultPrintMode: 'thermal80' })}
                className={`p-3 border rounded-xl font-bold transition-all ${
                  formData.defaultPrintMode === 'thermal80' ? 'bg-blue-900 text-white' : 'bg-slate-50'
                }`}
              >
                طابعة حرارية 80 مم
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, defaultPrintMode: 'thermal58' })}
                className={`p-3 border rounded-xl font-bold transition-all ${
                  formData.defaultPrintMode === 'thermal58' ? 'bg-blue-900 text-white' : 'bg-slate-50'
                }`}
              >
                طابعة حرارية 58 مم (بلوتوث)
              </button>
            </div>
          </div>

          <div>
            <label className="block font-bold mb-1">الشروط والملاحظات المطبوعة أسفل الفاتورة:</label>
            <textarea
              rows={2}
              value={formData.invoiceNotes}
              onChange={(e) => setFormData({ ...formData, invoiceNotes: e.target.value })}
              className="w-full border rounded-xl p-2.5"
            />
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.allowNegativeStock}
                onChange={(e) => setFormData({ ...formData, allowNegativeStock: e.target.checked })}
                className="w-4 h-4 rounded text-blue-900"
              />
              <span className="font-bold text-slate-800">
                السماح بالبيع بالسالب (تجاوز رصيد المخزن في حالات الطوارئ)
              </span>
            </label>
          </div>

          <div className="flex justify-end pt-3">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-black rounded-xl shadow-md"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الإعدادات</span>
            </button>
          </div>
        </div>
      </form>

      {/* Database Backup & Restore (Requirements 19 & 20) */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-xs">
        <h3 className="text-sm font-black text-slate-900 border-b pb-2 flex items-center gap-2">
          <Database className="w-4 h-4 text-blue-900" />
          <span>النسخ الاحتياطي واستعادة قاعدة البيانات (Backup & Recovery)</span>
        </h3>
        <p className="text-slate-500 leading-relaxed">
          يمكنك في أي وقت تنزيل نسخة احتياطية كاملة ومأمونة من كافة فواتير المبيعات، المشتريات، حركة الخزائن، حسابات العملاء والموردين بصيغة JSON، واستعادتها على أي جهاز كمبيوتر أو هاتف محمول.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          {/* Download Backup */}
          <div className="p-4 bg-slate-50 border rounded-2xl space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-2">
              <Download className="w-4 h-4 text-blue-900" />
              <span>تصدير نسخة احتياطية كاملة</span>
            </h4>
            <p className="text-[11px] text-slate-500">
              توليد ملف مشفر ومفصل لجميع قيود المنظومة لحفظه على قرص خارجي أو فلاش ميموري
            </p>
            <button
              type="button"
              onClick={exportBackup}
              className="w-full py-2.5 px-4 bg-blue-900 hover:bg-blue-950 text-white font-bold rounded-xl shadow-xs text-center"
            >
              تنزيل ملف النسخة الاحتياطية الآن
            </button>
          </div>

          {/* Restore Backup */}
          <div className="p-4 bg-slate-50 border rounded-2xl space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-2">
              <Upload className="w-4 h-4 text-emerald-700" />
              <span>استعادة نسخة احتياطية سابقة</span>
            </h4>
            <p className="text-[11px] text-slate-500">
              رفع ملف النسخة الاحتياطية (JSON) واسترجاع كامل العمليات والأرصدة بأمان
            </p>
            <label className="w-full block py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-center cursor-pointer shadow-xs">
              <span>اختر ملف النسخة واستعادتها</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Complete System Zero / Factory Reset */}
      <div className="bg-red-50/70 border border-red-200 p-6 rounded-2xl shadow-xs space-y-3 text-xs">
        <div className="flex items-center gap-2 text-red-900 font-black text-sm">
          <Trash2 className="w-5 h-5 text-red-600" />
          <span>تصفير المنظومة بالكامل (إعادة ضبط المصنع)</span>
        </div>
        <p className="text-red-700 leading-relaxed">
          حذف كافة البيانات المسجلة نهائياً (الأصناف، العملاء، الموردين، الفواتير، الموظفين، المناديب، والشيكات) وإعادة البرنامج كأنه جديد تماماً مع الاحتفاظ بحساب المسؤول العام الرئيسي (admin) فقط.
        </p>
        <div className="pt-1">
          <button
            type="button"
            disabled={isResetting}
            onClick={handleResetSystem}
            className="flex items-center gap-2 px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{isResetting ? 'جاري تصفير البيانات...' : 'تصفير كل شيء وحذف كافة البيانات والبدء من جديد'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
