import React, { useState, useMemo } from 'react';
import { 
  ArrowLeftRight, CheckCircle2, XCircle, Clock, AlertCircle, Plus, 
  Search, Filter, ShieldCheck, Printer, History, User, Building2, 
  HelpCircle, Check 
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import { useAuth } from '../../../context/AuthContext';
import { RepTransfer } from '../../../types';
import { Modal } from '../../common/Modal';
import { PrintDocumentModal, PrintData } from '../../common/PrintDocument';

export const RepTransferView: React.FC = () => {
  const { 
    repTransfers, representatives, cashboxes, settings, 
    createRepTransfer, confirmRepTransferReceipt, rejectRepTransfer 
  } = useData();
  const { currentUser } = useAuth();

  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeTransferForAudit, setActiveTransferForAudit] = useState<RepTransfer | null>(null);

  // New transfer form state
  const [direction, setDirection] = useState<'owner_to_rep' | 'rep_to_owner'>('rep_to_owner');
  const [selectedRepId, setSelectedRepId] = useState<string>(representatives[0]?.id || '');
  const [selectedCashboxId, setSelectedCashboxId] = useState<string>(cashboxes[0]?.id || '');
  const [amount, setAmount] = useState<number>(0);
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Print state
  const [printData, setPrintData] = useState<PrintData | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Role constraint: If current user is a representative, default to rep_to_owner and filter to their own transfers
  const isRepUser = currentUser?.role === 'representative';
  const myRepProfile = useMemo(() => {
    return representatives.find(r => r.userId === currentUser?.id || r.name === currentUser?.fullName);
  }, [representatives, currentUser]);

  const filteredTransfers = useMemo(() => {
    return repTransfers.filter(t => {
      // If representative user, only show transfers where they are sender or receiver
      if (isRepUser && myRepProfile) {
        if (t.senderId !== myRepProfile.id && t.receiverId !== myRepProfile.id) {
          return false;
        }
      }

      const matchesSearch = 
        t.transferNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.senderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.receiverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (t.notes && t.notes.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesStatus = statusFilter === 'all' ? true : t.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [repTransfers, searchTerm, statusFilter, isRepUser, myRepProfile]);

  const handleCreateTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      setError('يرجى إدخال مبلغ تحويل صحيح أكبر من صفر');
      return;
    }
    setError(null);
    setIsSubmitting(true);

    const rep = representatives.find(r => r.id === selectedRepId);
    if (!rep) {
      setError('يرجى اختيار المندوب');
      setIsSubmitting(false);
      return;
    }

    let senderId = '';
    let senderName = '';
    let receiverId = '';
    let receiverName = '';

    if (direction === 'rep_to_owner') {
      senderId = rep.id;
      senderName = `${rep.name} (مندوب)`;
      receiverId = 'USR-ADMIN';
      receiverName = 'الفرع الرئيسي / الإدارة';
    } else {
      senderId = 'USR-ADMIN';
      senderName = 'الفرع الرئيسي / الإدارة';
      receiverId = rep.id;
      receiverName = `${rep.name} (مندوب)`;
    }

    const res = await createRepTransfer({
      direction,
      senderId,
      senderName,
      receiverId,
      receiverName,
      amount,
      cashboxId: selectedCashboxId,
      notes,
    });

    setIsSubmitting(false);

    if (res.success) {
      setIsNewModalOpen(false);
      setAmount(0);
      setNotes('');
      // Trigger receipt print voucher
      if (res.transfer) {
        handlePrintTransfer(res.transfer);
      }
    } else {
      setError(res.error || 'تعذر إرسال طلب التحويل');
    }
  };

  const handleConfirmReceipt = async (t: RepTransfer) => {
    if (!window.confirm(`هل أنت متأكد من تأكيد استلام مبلغ (${t.amount.toLocaleString()} ${settings.currency}) الخاص بالتحويل ${t.transferNumber}؟ سيتم تحديث أرصدة الخزينة وحساب المندوب فوراً.`)) {
      return;
    }

    const res = await confirmRepTransferReceipt(t.id, 'تم التأكيد والاستلام الفعلي');
    if (!res.success) {
      alert(res.error || 'فشل تأكيد الاستلام');
    }
  };

  const handleRejectTransfer = async (t: RepTransfer) => {
    const reason = prompt('يرجى إدخال سبب رفض استلام هذا التحويل:');
    if (!reason) return;

    const res = await rejectRepTransfer(t.id, reason);
    if (!res.success) {
      alert(res.error || 'فشل رفض التحويل');
    }
  };

  const handlePrintTransfer = (t: RepTransfer) => {
    setPrintData({
      title: 'إيصال طلب تحويل بالنصف (إشعار تحويل مالي بين المندوب والفرع)',
      docNumber: t.transferNumber,
      docType: 'إيصال استلام',
      date: t.date,
      partyName: t.direction === 'rep_to_owner' ? t.senderName : t.receiverName,
      representativeName: t.direction === 'rep_to_owner' ? t.senderName : t.receiverName,
      grandTotal: t.amount,
      paidAmount: t.amount,
      paymentType: 'تحويل نقدي بالنصف',
      notes: `حالة التحويل: ${t.status === 'received' ? 'تم الاستلام والتأكيد' : 'قيد الاستلام'} | الخزينة: ${t.cashboxName} | ملاحظات: ${t.notes || 'لا يوجد'}`,
    });
    setIsPrintModalOpen(true);
  };

  const getStatusBadge = (status: RepTransfer['status']) => {
    switch (status) {
      case 'received':
        return (
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>تم الاستلام وتعديل الأرصدة</span>
          </span>
        );
      case 'awaiting_receipt':
        return (
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-300 text-xs font-bold animate-pulse">
            <Clock className="w-3.5 h-3.5" />
            <span>في انتظار تأكيد الاستلام</span>
          </span>
        );
      case 'rejected':
        return (
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-50 text-red-700 border border-red-200 text-xs font-bold">
            <XCircle className="w-3.5 h-3.5" />
            <span>مرفوض</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
            ملغى
          </span>
        );
      default:
        return <span className="text-xs font-bold text-slate-500">جديد</span>;
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              طلب تحويل بالنصف
            </h2>
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 text-xs font-bold border border-blue-200">
              نظام التأكيد التبادلي المعتمد
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
            نظام التحويلات المالية التبادلية بين الإدارة والمندوبين. لا تتغير الأرصدة المالية والمحاسبية إلا بعد تأكيد استلام الطرف المتلقي للطلب منعاً لأي ازدواجية أو أخطاء.
          </p>
        </div>

        <button
          onClick={() => setIsNewModalOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-950 text-white text-xs font-black shadow-lg shadow-blue-900/20 transition-all active:scale-95 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>إنشاء طلب تحويل بالنصف جديد</span>
        </button>
      </div>

      {/* Rules Banner (Spec Requirement 15) */}
      <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900">
        <HelpCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <strong className="block font-black text-amber-950">
            قواعد وضوابط نظام "طلب تحويل بالنصف":
          </strong>
          <p className="leading-relaxed">
            1. يتم تحويل المبالغ بين الفرع والمندوبين في كلا الاتجاهين (توريد تحصيلات مبيعات من المندوب أو صرف عهدة من الإدارة للمندوب).<br />
            2. لا يتم خصم أو إضافة المبلغ لحساب أي طرف فور الإرسال، بل يظل بحالة "قيد الاستلام".<br />
            3. تتغير الأرصدة المالية وقيود الخزينة فقط وحصرياً بعد ضغط الطرف المستلم على زر "تأكيد الاستلام".
          </p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[240px] relative">
          <input
            type="text"
            placeholder="بحث برقم التحويل، الطرف المرسل، أو المستلم..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2 pr-9 pl-3 text-xs focus:bg-white focus:border-blue-600 outline-hidden"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-bold">الحالة:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 outline-hidden focus:border-blue-600"
          >
            <option value="all">جميع الحالات</option>
            <option value="awaiting_receipt">في انتظار تأكيد الاستلام (معلق)</option>
            <option value="received">تم الاستلام وتعديل الأرصدة</option>
            <option value="rejected">مرفوض</option>
          </select>
        </div>
      </div>

      {/* Transfers List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3.5">رقم التحويل</th>
                <th className="p-3.5">التاريخ والوقت</th>
                <th className="p-3.5">اتجاه التحويل</th>
                <th className="p-3.5">الطرف المرسل</th>
                <th className="p-3.5">الطرف المستلم</th>
                <th className="p-3.5">المبلغ</th>
                <th className="p-3.5">الخزينة المتأثرة</th>
                <th className="p-3.5">الحالة</th>
                <th className="p-3.5 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransfers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400">
                    لا توجد طلبات تحويل مطابقة لمعايير البحث الحالية
                  </td>
                </tr>
              ) : (
                filteredTransfers.map(t => {
                  const isAwaiting = t.status === 'awaiting_receipt';
                  return (
                    <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5 font-bold font-mono text-blue-900">{t.transferNumber}</td>
                      <td className="p-3.5 text-slate-600 font-mono">
                        <div>{t.date}</div>
                        <div className="text-[10px] text-slate-400">{new Date(t.timestamp).toLocaleTimeString('ar-EG')}</div>
                      </td>
                      <td className="p-3.5">
                        {t.direction === 'rep_to_owner' ? (
                          <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold">
                            توريد: مندوب ⬅ فرع
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-800 border border-purple-200 text-[10px] font-bold">
                            صرف عهدة: فرع ⬅ مندوب
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 font-bold text-slate-800">{t.senderName}</td>
                      <td className="p-3.5 font-bold text-slate-800">{t.receiverName}</td>
                      <td className="p-3.5 font-black text-sm text-blue-950 font-mono">
                        {t.amount.toLocaleString()} {settings.currency}
                      </td>
                      <td className="p-3.5 text-slate-600">{t.cashboxName}</td>
                      <td className="p-3.5">{getStatusBadge(t.status)}</td>
                      <td className="p-3.5">
                        <div className="flex items-center justify-center gap-1.5">
                          {isAwaiting && (
                            <>
                              <button
                                onClick={() => handleConfirmReceipt(t)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs transition-all active:scale-95"
                                title="تأكيد الاستلام الفعلي واعتماد القيد المالي"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>تأكيد الاستلام</span>
                              </button>
                              <button
                                onClick={() => handleRejectTransfer(t)}
                                className="p-1 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors"
                                title="رفض الطلب"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => handlePrintTransfer(t)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-900 hover:bg-blue-50 transition-colors"
                            title="طباعة إيصال التحويل"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setActiveTransferForAudit(t)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                            title="سجل التتبع والمصادقة"
                          >
                            <History className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Transfer Modal */}
      <Modal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        title="إنشاء طلب تحويل بالنصف جديد"
        subtitle="إرسال طلب تحويل مالي بين الإدارة والمندوب ينتظر تأكيد الاستلام لتعديل الأرصدة"
        maxWidth="xl"
      >
        <form onSubmit={handleCreateTransfer} className="space-y-4 text-xs">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 font-bold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Direction Selector */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">اتجاه التحويل:</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setDirection('rep_to_owner')}
                className={`p-3 rounded-xl border font-bold text-right transition-all ${
                  direction === 'rep_to_owner'
                    ? 'bg-blue-900 text-white border-blue-900 shadow-md'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <User className="w-4 h-4 text-amber-400" />
                  <span>المندوب يرسل للإدارة</span>
                </div>
                <p className="text-[10px] font-normal opacity-80">
                  توريد نقدية ومتحصلات من المندوب إلى خزينة الفرع
                </p>
              </button>

              <button
                type="button"
                onClick={() => setDirection('owner_to_rep')}
                className={`p-3 rounded-xl border font-bold text-right transition-all ${
                  direction === 'owner_to_rep'
                    ? 'bg-blue-900 text-white border-blue-900 shadow-md'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Building2 className="w-4 h-4 text-sky-400" />
                  <span>الإدارة ترسل للمندوب</span>
                </div>
                <p className="text-[10px] font-normal opacity-80">
                  صرف عهدة ومصاريف تشغيل من الخزينة لحساب المندوب
                </p>
              </button>
            </div>
          </div>

          {/* Representative */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">المندوب المعني:</label>
            <select
              value={selectedRepId}
              onChange={(e) => setSelectedRepId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs font-bold outline-hidden focus:border-blue-600 focus:bg-white"
            >
              {representatives.length === 0 ? (
                <option value="">-- لا يوجد مناديب مسجلين بعد (يرجى إضافة مندوب أولاً) --</option>
              ) : (
                representatives.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.name} - (رصيده الحالي: {r.currentBalance} {settings.currency})
                  </option>
                ))
              )}
            </select>
          </div>

          {/* Target Cashbox */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">خزينة الفرع المتأثرة:</label>
            <select
              value={selectedCashboxId}
              onChange={(e) => setSelectedCashboxId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs font-bold outline-hidden focus:border-blue-600 focus:bg-white"
            >
              {cashboxes.map(cb => (
                <option key={cb.id} value={cb.id}>
                  {cb.name} - (رصيدها: {cb.currentBalance} {settings.currency})
                </option>
              ))}
            </select>
          </div>

          {/* Amount */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">المبلغ المراد تحويله ({settings.currency}):</label>
            <input
              type="number"
              min="1"
              required
              value={amount || ''}
              onChange={(e) => setAmount(Number(e.target.value))}
              placeholder="مثال: 5000"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-black font-mono text-blue-900 outline-hidden focus:border-blue-600 focus:bg-white text-center"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">ملاحظات التحويل:</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="أدخل أي ملاحظات تخص خط السير أو نوع العهدة..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-hidden focus:border-blue-600 focus:bg-white"
            />
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] font-medium leading-relaxed">
            * تنبيه: بمجرد الحفظ سيتم إنشاء إشعار "طلب تحويل بالنصف" ولن يتم التأثير على الخزينة أو حساب المندوب إلا بعد قيام الطرف الآخر بتأكيد الاستلام.
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsNewModalOpen(false)}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-100"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-950 text-white font-black shadow-md shadow-blue-900/20 active:scale-95 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? 'جاري الإرسال...' : 'إرسال طلب التحويل بالنصف'}</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* Audit Trail Modal */}
      {activeTransferForAudit && (
        <Modal
          isOpen={!!activeTransferForAudit}
          onClose={() => setActiveTransferForAudit(null)}
          title={`سجل تدقيق التحويل: ${activeTransferForAudit.transferNumber}`}
          subtitle="تاريخ الحركات وتأكيدات الاستلام والاعتمادات"
          maxWidth="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center">
              <div>
                <span className="block text-slate-500">المبلغ المحول:</span>
                <span className="text-sm font-black text-blue-950 font-mono">
                  {activeTransferForAudit.amount.toLocaleString()} {settings.currency}
                </span>
              </div>
              <div>{getStatusBadge(activeTransferForAudit.status)}</div>
            </div>

            <div className="space-y-3 relative before:absolute before:top-2 before:bottom-2 before:right-3.5 before:w-0.5 before:bg-slate-200">
              {activeTransferForAudit.auditTrail.map((log, idx) => (
                <div key={idx} className="relative flex items-start gap-3 mr-1">
                  <div className="w-6 h-6 rounded-full bg-blue-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0 z-10">
                    {idx + 1}
                  </div>
                  <div className="flex-1 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold text-slate-900">{log.action}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(log.timestamp).toLocaleString('ar-EG')}
                      </span>
                    </div>
                    <div className="text-slate-600">
                      بواسطة: <strong className="text-blue-900">{log.user}</strong>
                    </div>
                    {log.note && (
                      <p className="mt-1 text-[11px] text-slate-500 italic">"{log.note}"</p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-3 border-t">
              <button
                onClick={() => setActiveTransferForAudit(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
              >
                إغلاق
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Print Document Modal */}
      <PrintDocumentModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        data={printData}
      />
    </div>
  );
};
