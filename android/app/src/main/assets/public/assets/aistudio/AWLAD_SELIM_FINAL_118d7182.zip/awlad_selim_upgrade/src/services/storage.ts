import { 
  User, Product, Warehouse, Customer, Supplier, Invoice, 
  InvoiceReturn, Cashbox, FinancialTransaction, Cheque, 
  InstallmentSchedule, Representative, RepTransfer, Employee, 
  EmployeeAdvanceDeduction, AttendanceRecord, SalaryPayroll, 
  ExpenseIncomeRecord, StockMovement, AuditLogItem, SystemSettings,
  RepItemTransferRequest, ServerConnectionSettings, ProductCategory, CustomerItemOrderRequest
} from '../types';

const STORAGE_KEY = 'awlad_selim_database_v2_fresh';
const AUDIT_LOG_KEY = 'awlad_selim_audit_logs_v2';
const SESSION_USER_KEY = 'awlad_selim_current_session';

// Secure hash function using Web Crypto SHA-256 with salt
export async function hashPassword(password: string): Promise<string> {
  const salt = 'awlad_selim_secure_salt_2026';
  const encoder = new TextEncoder();
  const data = encoder.encode(password + salt);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export interface DatabaseState {
  users: User[];
  products: Product[];
  warehouses: Warehouse[];
  customers: Customer[];
  suppliers: Supplier[];
  invoices: Invoice[];
  invoiceReturns: InvoiceReturn[];
  cashboxes: Cashbox[];
  financialTransactions: FinancialTransaction[];
  cheques: Cheque[];
  installments: InstallmentSchedule[];
  representatives: Representative[];
  repTransfers: RepTransfer[];
  repItemTransfers?: RepItemTransferRequest[];
  customerItemOrders?: CustomerItemOrderRequest[];
  employees: Employee[];
  advancesDeductions: EmployeeAdvanceDeduction[];
  attendance: AttendanceRecord[];
  payrolls: SalaryPayroll[];
  expenseIncomes: ExpenseIncomeRecord[];
  stockMovements: StockMovement[];
  categories?: ProductCategory[];
  settings: SystemSettings;
  serverSettings?: ServerConnectionSettings;
}

// Generate unique ID
export function generateId(prefix: string = 'AS'): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`.toUpperCase();
}

// Brand New Clean Initial Database (Zeroed out with initial admin only)
export async function getInitialDatabase(): Promise<DatabaseState> {
  // Initial local test administrator. Credentials are intentionally not rendered in the login UI.
  const adminHash = await hashPassword('123456');

  const defaultPermissions = {
    canView: true,
    canAdd: true,
    canEdit: true,
    canDelete: true,
    canPrint: true,
    canExport: true,
    canViewReports: true,
    canManageSales: true,
    canManagePurchases: true,
    canManageInventory: true,
    canManageWarehouses: true,
    canManageCashboxes: true,
    canManageAccounts: true,
    canManageReps: true,
    canManageTransfers: true,
    canManageEmployees: true,
    canManageSalaries: true,
    canManageUsers: true,
    canManageSettings: true,
    canAllowNegativeInventory: false,
  };

  // Only the initial administrator account
  const users: User[] = [
    {
      id: 'USR-ADMIN',
      fullName: 'المدير العام (أولاد سليم)',
      username: 'AHMED',
      passwordHash: adminHash,
      phone: '',
      role: 'admin',
      jobTitle: 'مالك ومدير النظام',
      department: 'الإدارة العليا',
      isActive: true,
      mustChangePassword: false,
      permissions: { ...defaultPermissions },
      createdAt: new Date().toISOString(),
    }
  ];

  // Default main warehouse
  const warehouses: Warehouse[] = [
    {
      id: 'WH-01',
      name: 'المستودع الرئيسي (المركز)',
      code: 'WH-MAIN',
      location: 'المنطقة الصناعية - المقر الرئيسي',
      managerName: 'المدير العام',
      phone: '01012345678',
      isDefault: true,
    }
  ];

  // Default main cashbox with 0 balance
  const cashboxes: Cashbox[] = [
    {
      id: 'CASH-01',
      name: 'الخزينة الرئيسية',
      type: 'cashbox',
      openingBalance: 0,
      currentBalance: 0,
      isDefault: true,
    }
  ];

  const settings: SystemSettings = {
    companyName: 'أولاد سليم لتجارة المواد الغذائية بالجملة',
    companySubtitle: 'AWLAD SELIM - برنامج محاسبة وإدارة الأعمال المتكامل',
    phone1: '01012345678',
    phone2: '01123456789',
    address: 'المنطقة الصناعية / سوق الجملة',
    commercialRegistration: 'س.ت: 789452',
    taxNumber: 'ب.ض: 452-987-123',
    currency: 'ج.م',
    defaultPrintMode: 'a4',
    invoiceNotes: 'البضاعة المباعة لا ترد ولا تستبدل بعد مرور 14 يوماً من تاريخ الفاتورة ويشترط سلامة العبوة الأصلية.',
    allowNegativeStock: false,
  };

  return {
    users,
    products: [],              // صفر أصناف
    warehouses,
    customers: [],             // صفر عملاء
    suppliers: [],             // صفر موردين
    invoices: [],              // صفر فواتير مبيعات ومشتريات
    invoiceReturns: [],        // صفر مرتجعات
    cashboxes,
    financialTransactions: [], // صفر حركات مالية
    cheques: [],               // صفر شيكات
    installments: [],          // صفر أقساط
    representatives: [],       // صفر مناديب
    repTransfers: [],          // صفر تحويلات
    repItemTransfers: [],      // طلبات تحويل الأصناف والعهد المرتبطة بالفواتير
    customerItemOrders: [],    // طلبات أصناف العملاء دون تسعير أو فاتورة تلقائية
    employees: [],             // صفر موظفين
    advancesDeductions: [],
    attendance: [],
    payrolls: [],
    expenseIncomes: [],        // صفر مصروفات وإيرادات
    stockMovements: [],        // صفر حركات مخزنية
    categories: [
      { id: 'CAT-01', name: 'شيبسيات ومقرمشات', status: 'active', createdAt: new Date().toISOString() },
      { id: 'CAT-02', name: 'مشروبات وعصائر', status: 'active', createdAt: new Date().toISOString() },
      { id: 'CAT-03', name: 'بسكويت وحلويات', status: 'active', createdAt: new Date().toISOString() },
      { id: 'CAT-04', name: 'زيوت وسمن', status: 'active', createdAt: new Date().toISOString() },
      { id: 'CAT-05', name: 'معلبات ومواد غذائية', status: 'active', createdAt: new Date().toISOString() },
    ],
    settings,
    serverSettings: {
      serverIp: '192.168.1.100',
      hostname: 'awlad-selim-server',
      port: 3000,
      apiBaseUrl: 'http://192.168.1.100:3000',
      connectionType: 'lan',
      serverStatus: 'online',
      databaseStatus: 'connected',
      latencyMs: 14,
      syncStatus: 'connected',
      lastSuccessfulConnection: new Date().toISOString(),
    },
  };
}

// Local storage management
export async function loadDatabase(): Promise<DatabaseState> {
  try {
    // If older seeded database version exists, clean it up
    if (localStorage.getItem('awlad_selim_database_v1')) {
      localStorage.removeItem('awlad_selim_database_v1');
      localStorage.removeItem('awlad_selim_audit_logs');
    }

    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = await getInitialDatabase();
      saveDatabase(initial);
      return initial;
    }
    const parsed = JSON.parse(raw) as DatabaseState;
    if (!parsed.users || parsed.users.length === 0) {
      const initial = await getInitialDatabase();
      saveDatabase(initial);
      return initial;
    }

    // Keep the requested owner test account stable and never render its credentials in the UI.
    const ownerHash = await hashPassword('123456');
    const ownerIndex = parsed.users.findIndex(u => u.username?.toUpperCase() === 'AHMED' && u.role === 'admin');
    if (ownerIndex >= 0) {
      parsed.users[ownerIndex] = { ...parsed.users[ownerIndex], passwordHash: ownerHash, isActive: true, mustChangePassword: false };
    } else {
      const fresh = await getInitialDatabase();
      parsed.users = [...fresh.users, ...parsed.users];
    }
    if (!parsed.repItemTransfers) { parsed.repItemTransfers = []; }
    if (!parsed.customerItemOrders) { parsed.customerItemOrders = []; }
    if (!parsed.categories) {
      parsed.categories = [
        { id: 'CAT-01', name: 'شيبسيات ومقرمشات', status: 'active', createdAt: new Date().toISOString() },
        { id: 'CAT-02', name: 'مشروبات وعصائر', status: 'active', createdAt: new Date().toISOString() },
        { id: 'CAT-03', name: 'بسكويت وحلويات', status: 'active', createdAt: new Date().toISOString() },
        { id: 'CAT-04', name: 'زيوت وسمن', status: 'active', createdAt: new Date().toISOString() },
        { id: 'CAT-05', name: 'معلبات ومواد غذائية', status: 'active', createdAt: new Date().toISOString() },
      ];
    }
    if (!parsed.serverSettings) {
      parsed.serverSettings = {
        serverIp: '192.168.1.100',
        hostname: 'awlad-selim-server',
        port: 3000,
        apiBaseUrl: 'http://192.168.1.100:3000',
        connectionType: 'lan',
        serverStatus: 'online',
        databaseStatus: 'connected',
        latencyMs: 14,
        syncStatus: 'connected',
        lastSuccessfulConnection: new Date().toISOString(),
      };
    }
    return parsed;
  } catch (error) {
    console.error('Error loading database from storage:', error);
    const initial = await getInitialDatabase();
    return initial;
  }
}

export function saveDatabase(data: DatabaseState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving database to storage:', error);
  }
}

// Complete factory reset helper
export async function resetDatabaseToFactoryFresh(): Promise<DatabaseState> {
  const fresh = await getInitialDatabase();
  saveDatabase(fresh);
  try {
    localStorage.removeItem(AUDIT_LOG_KEY);
    localStorage.removeItem('awlad_selim_audit_logs');
    localStorage.removeItem('awlad_selim_database_v1');
  } catch (e) {
    console.error(e);
  }
  return fresh;
}

// Audit Log helpers
export function logAuditEvent(item: Omit<AuditLogItem, 'id' | 'timestamp'>): void {
  try {
    const existingRaw = localStorage.getItem(AUDIT_LOG_KEY);
    const logs: AuditLogItem[] = existingRaw ? JSON.parse(existingRaw) : [];
    const newLog: AuditLogItem = {
      id: generateId('LOG'),
      timestamp: new Date().toISOString(),
      ...item,
    };
    logs.unshift(newLog); // newest first
    if (logs.length > 500) logs.pop();
    localStorage.setItem(AUDIT_LOG_KEY, JSON.stringify(logs));
  } catch (err) {
    console.error('Failed to log audit event', err);
  }
}

export function getAuditLogs(): AuditLogItem[] {
  try {
    const existingRaw = localStorage.getItem(AUDIT_LOG_KEY);
    return existingRaw ? JSON.parse(existingRaw) : [];
  } catch {
    return [];
  }
}
