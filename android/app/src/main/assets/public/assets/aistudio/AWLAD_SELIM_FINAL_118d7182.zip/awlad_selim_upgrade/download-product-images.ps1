﻿$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$folder = Join-Path $root "public\\product-images"
New-Item -ItemType Directory -Force -Path $folder | Out-Null
$ids = @(1002, 1006, 1008, 1009, 1012, 1015, 1018, 1021, 1023, 1025, 1028, 1031, 1040, 1041, 1042, 1043, 1048, 1049, 1057, 1061, 1063, 1064, 1069, 1071, 1076, 1092, 1093, 1094, 1095, 1102, 1106, 1111, 1112, 1113, 1114, 1117, 1118, 1251, 1271, 1274, 1276, 1281, 1282, 1283, 1284, 1285, 1295, 1296, 1297, 1305, 1330, 1331, 1332, 1333, 1338, 1344, 1345, 1346, 1347, 1403, 1453, 1459, 1460, 1461, 1505, 1510, 1517, 1518, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1561, 1562, 1563, 1564, 1574, 1599, 1600, 1617, 1655, 1668, 1681, 1690, 1726, 1737, 1738, 1740, 1781, 2826, 2842, 2843, 2845, 2853, 2863, 2864, 2882, 2893, 2907, 2915, 2933, 2948, 2950, 2959, 2988, 3002, 3003, 3004, 3305, 3306, 3307, 3308, 3309, 3310, 3311, 3312, 3313, 3314, 3315, 3316, 3317, 3318, 3319, 3320, 3321, 3322, 3323, 3324, 3325, 3326, 3327, 3328, 3329, 3330, 3331, 3332, 3333, 4007, 4008, 4009, 4010, 4011, 4015, 4021, 4023, 4024, 4025, 4026, 4027, 4028, 4029, 4030, 4031, 4032, 4033, 4034, 4035, 4036, 4037, 4038, 4039, 4040, 4041, 4042, 4043, 4044, 4045, 4046, 4047, 4048, 4049, 4050, 4051, 4052, 4053, 4054, 4055, 4056, 4057, 4058, 4059, 4060, 4061, 4062, 4063, 4064, 4065, 4066, 4067, 4068, 4069, 4070, 4071, 4072, 4073, 4074, 4075, 4076, 4077, 4078, 4079, 4080, 4081, 4082)
$failed = @()
foreach ($id in $ids) {
  $url = "http://78.89.159.126:9393/TheOneAboLasheenAPI/ItemsPhoto/$id.jpg"
  $out = Join-Path $folder "$id.jpg"
  try {
    Invoke-WebRequest -Uri $url -OutFile $out -TimeoutSec 20 -UseBasicParsing
    if ((Test-Path $out) -and (Get-Item $out).Length -gt 100) {
      Write-Host "OK $id.jpg" -ForegroundColor Green
    } else { $failed += $id }
  } catch { $failed += $id; Write-Host "FAILED $id" -ForegroundColor Red }
}
$failed | Out-File (Join-Path $folder "Failed.txt") -Encoding utf8
Write-Host "Downloaded: $($ids.Count - $failed.Count) / $($ids.Count)"
Write-Host "Images folder: $folder"
