@echo off
chcp 65001 > nul
title AWLAD SELIM Server
echo جاري تشغيل خادم أولاد سليم على الشبكة المحلية...
node server.js
pause
